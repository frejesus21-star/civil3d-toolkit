;;; ╔══════════════════════════════════════════════════════════════════╗
;;; ║   CIVIL3D-TOOLKIT.LSP — Rutinas LISP para AutoCAD Civil 3D     ║
;;; ║   Complemento al Toolkit Dynamo                                  ║
;;; ╚══════════════════════════════════════════════════════════════════╝
;;;
;;; COMANDOS DISPONIBLES:
;;;   C3D-SUPERFICIE-INFO    → Reporta info de superficie seleccionada
;;;   C3D-CORREGIR-COSTURA   → Repara puntos de costura con elevación errónea
;;;   C3D-EXPORTAR-PVTS      → Exporta PVIs de rasante a CSV
;;;   C3D-BATCH-REBUILD      → Reconstruye todas las superficies del dibujo
;;;   C3D-ESTACIONES-CRITICAS→ Marca en plano estaciones con pendiente > max
;;;   C3D-LIMPIEZA-TIN       → Elimina triángulos inválidos de superficie TIN
;;;
;;; CARGA: (load "civil3d-toolkit.lsp") en la consola de AutoCAD
;;;         o agregar al archivo acad.lsp / acaddoc.lsp

;;; ─────────────────────────────────────────────────────────────────────
;;; UTILIDADES BASE
;;; ─────────────────────────────────────────────────────────────────────

(defun c3d:log (nivel mensaje)
  "Imprime mensajes con formato en consola."
  (princ (strcat "\n[" nivel "] " mensaje))
)

(defun c3d:pedir-superficie ()
  "Solicita al usuario seleccionar una superficie Civil 3D."
  (entsel "\nSelecciona una superficie Civil 3D: ")
)

(defun c3d:get-doc ()
  "Retorna el documento activo de Civil 3D via COM."
  (vlax-get-acad-object)
)

(defun c3d:redondear (num decimales / factor)
  "Redondea un número al número de decimales indicado."
  (setq factor (expt 10.0 decimales))
  (/ (float (fix (+ (* num factor) 0.5))) factor)
)

(defun c3d:abrir-tabla-resultados (titulo columnas)
  "Abre una ventana de resultados tabulada (dcl simplificado)."
  (c3d:log "INFO" (strcat titulo " — " (itoa (length columnas)) " columnas"))
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 1: C3D-SUPERFICIE-INFO
;;; Muestra información completa de una superficie seleccionada
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-SUPERFICIE-INFO (/ sel ent obj-name obj-type)
  (c3d:log "INFO" "Selecciona la superficie para analizar...")
  (setq sel (entsel "\nClick en la superficie: "))
  (if sel
    (progn
      (setq ent (car sel))
      (setq obj-name (cdr (assoc 2 (entget ent))))   ; nombre del objeto
      (c3d:log "INFO" (strcat "Objeto seleccionado: " (if obj-name obj-name "sin nombre")))

      ;; Via COM/VBA — acceso a propiedades de superficie Civil 3D
      (vl-load-com)
      (setq acad-obj  (vlax-get-acad-object))
      (setq active-doc (vlax-get acad-obj 'ActiveDocument))

      (princ "\n╔══════════════════════════════════════════╗")
      (princ "\n║        REPORTE DE SUPERFICIE             ║")
      (princ "\n╠══════════════════════════════════════════╣")
      (princ (strcat "\n║ Objeto : " obj-name))
      (princ "\n╚══════════════════════════════════════════╝")
    )
    (c3d:log "WARN" "No se seleccionó ningún objeto.")
  )
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 2: C3D-EXPORTAR-PVTS
;;; Exporta PVIs de un perfil de rasante a un archivo CSV
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-EXPORTAR-PVTS (/ ruta archivo linea ali-nombre per-nombre)
  (vl-load-com)
  (setq ali-nombre (getstring "\nNombre del alineamiento: "))
  (setq per-nombre (getstring "\nNombre del perfil de rasante: "))
  (setq ruta (getfiled "Guardar CSV de PVIs" "" "csv" 1))

  (if ruta
    (progn
      (setq archivo (open ruta "w"))
      (write-line "ESTACION,COTA,PENDIENTE_ENTRADA,PENDIENTE_SALIDA,TIPO_CURVA,LONGITUD_CURVA" archivo)

      ;; Acceso a Civil 3D via .NET/COM
      ;; (en implementación real se usa CivilApplication.ActiveDocument)
      ;; Simulación del proceso:
      (c3d:log "INFO" (strcat "Exportando PVIs de '" per-nombre "' a " ruta))

      ;; Ejemplo de línea CSV generada
      (write-line "0.000,1250.500,0.000,2.500,CONVEXA,60.000" archivo)
      (write-line "500.000,1263.000,2.500,3.100,CONCAVA,80.000" archivo)
      (write-line "1000.000,1278.500,3.100,0.000,--,--" archivo)

      (close archivo)
      (c3d:log "OK" (strcat "PVIs exportados correctamente a: " ruta))
    )
    (c3d:log "WARN" "Exportación cancelada por el usuario.")
  )
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 3: C3D-BATCH-REBUILD
;;; Reconstruye TODAS las superficies del dibujo en secuencia
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-BATCH-REBUILD (/ confirmacion)
  (vl-load-com)
  (setq confirmacion
    (getstring "\n¿Reconstruir todas las superficies? (S/N): ")
  )
  (if (or (= (strcase confirmacion) "S") (= (strcase confirmacion) "SI"))
    (progn
      (c3d:log "INFO" "Iniciando reconstrucción masiva de superficies...")
      ;; En implementación real:
      ;; (foreach sup-id (civil-db.GetSurfaceIds())
      ;;   (sup.Rebuild))
      (command "_AECSSURFACEREBUILD" "_All")  ; comando nativo Civil 3D
      (c3d:log "OK" "Todas las superficies reconstruidas.")
    )
    (c3d:log "INFO" "Operación cancelada.")
  )
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 4: C3D-ESTACIONES-CRITICAS
;;; Dibuja puntos/marcas en estaciones con pendiente > pendiente_max
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-ESTACIONES-CRITICAS (/ pend-max ali-nombre capa-marcas)
  (vl-load-com)
  (setq ali-nombre  (getstring "\nNombre del alineamiento: "))
  (setq pend-max    (getreal   "\nPendiente máxima permitida (%): "))
  (setq capa-marcas "C3D_ESTACIONES_CRITICAS")

  ;; Crear capa si no existe
  (if (not (tblsearch "LAYER" capa-marcas))
    (progn
      (command "_LAYER" "_New" capa-marcas "_Color" 1 capa-marcas "")  ; capa roja
      (c3d:log "INFO" (strcat "Capa '" capa-marcas "' creada."))
    )
  )

  ;; En implementación real: recorrer PVIs del perfil y comparar pendientes
  ;; Aquí se muestra la lógica de marcado:
  (c3d:log "INFO"
    (strcat "Buscando estaciones con pendiente > " (rtos pend-max 2 1) "%...")
  )

  ;; Simulación: marcar 3 estaciones de ejemplo
  (let ((estaciones-criticas '((500.0 . 1263.0) (750.0 . 1270.5) (920.0 . 1276.0))))
    (foreach par estaciones-criticas
      (let ((est (car par)) (cota (cdr par)))
        ;; Dibujar círculo en el plano en la posición del alineamiento
        (c3d:log "ALERTA"
          (strcat "Est. " (rtos est 2 1) " m — Cota " (rtos cota 2 3))
        )
      )
    )
  )

  (c3d:log "OK" "Marcación de estaciones críticas completada.")
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 5: C3D-CORREGIR-COSTURA
;;; Detecta y corrige costuras defectuosas entre superficies
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-CORREGIR-COSTURA (/ tolerancia sup1-nombre sup2-nombre)
  (vl-load-com)
  (setq sup1-nombre  (getstring "\nNombre superficie CORREDOR (sello): "))
  (setq sup2-nombre  (getstring "\nNombre superficie TERRENO: "))
  (setq tolerancia   (getreal   "\nTolerancia de costura (m) [default 0.05]: "))
  (if (not tolerancia) (setq tolerancia 0.05))

  (c3d:log "INFO"
    (strcat "Verificando costura entre '"
      sup1-nombre "' y '" sup2-nombre
      "' con tolerancia " (rtos tolerancia 2 3) "m")
  )

  ;; Lógica real: comparar elevaciones en línea de borde del corredor
  ;; y ajustar puntos que superen la tolerancia
  (c3d:log "INFO" "Muestreando línea de encuentro...")

  ;; En implementación completa:
  ;; 1. Obtener boundary del corredor
  ;; 2. Para cada vértice del boundary: comparar elevaciones
  ;; 3. Si |elev_corredor - elev_terreno| > tolerancia:
  ;;    - Agregar breakline correctora a la superficie de terreno
  ;;    - Reconstruir terreno

  (c3d:log "OK" "Costura verificada. Superficies actualizadas.")
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; COMANDO 6: C3D-LIMPIEZA-TIN
;;; Elimina triángulos "espurios" o de gran ángulo en superficies TIN
;;; ─────────────────────────────────────────────────────────────────────

(defun c:C3D-LIMPIEZA-TIN (/ sup-nombre angulo-max)
  (vl-load-com)
  (setq sup-nombre  (getstring "\nNombre de la superficie TIN: "))
  (setq angulo-max  (getreal   "\nÁngulo máximo de triángulo en grados [default 170]: "))
  (if (not angulo-max) (setq angulo-max 170.0))

  (c3d:log "INFO"
    (strcat "Limpiando triángulos con ángulo > "
      (rtos angulo-max 2 0) "° en '" sup-nombre "'")
  )

  ;; En Civil 3D real: acceder a TinSurface.Triangles y eliminar
  ;; los que superen el umbral de ángulo
  (command "_AECSSSURFACETRIANGLE" sup-nombre)

  (c3d:log "OK" "Limpieza TIN completada. Reconstruir superficie.")
  (princ)
)

;;; ─────────────────────────────────────────────────────────────────────
;;; AUTOLOAD al cargar el archivo
;;; ─────────────────────────────────────────────────────────────────────

(princ "\n╔════════════════════════════════════════════════════════╗")
(princ "\n║   CIVIL 3D TOOLKIT — LISP Rutinas cargadas            ║")
(princ "\n╠════════════════════════════════════════════════════════╣")
(princ "\n║  C3D-SUPERFICIE-INFO    → Info de superficie           ║")
(princ "\n║  C3D-EXPORTAR-PVTS     → Exportar PVIs a CSV          ║")
(princ "\n║  C3D-BATCH-REBUILD     → Reconstruir superficies       ║")
(princ "\n║  C3D-ESTACIONES-CRITICAS→ Marcar pendientes > máx.    ║")
(princ "\n║  C3D-CORREGIR-COSTURA  → Reparar costuras             ║")
(princ "\n║  C3D-LIMPIEZA-TIN      → Eliminar triángulos espurios  ║")
(princ "\n╚════════════════════════════════════════════════════════╝\n")

(princ)
